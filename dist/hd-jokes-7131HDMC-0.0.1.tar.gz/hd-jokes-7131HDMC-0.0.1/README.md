# HdJokes
Python library to choice a random joke in a refered language  